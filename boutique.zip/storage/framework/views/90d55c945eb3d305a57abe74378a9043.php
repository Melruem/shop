

<?php $__env->startSection('breadcrumbs'); ?>
    <div class="breadcrumbs">
       
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/widgets.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.vmap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.vmap.sampledata.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.vmap.world.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-commerce\boutique\resources\views/home.blade.php ENDPATH**/ ?>