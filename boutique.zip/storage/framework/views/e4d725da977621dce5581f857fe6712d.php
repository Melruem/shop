
<aside >
    <nav >


        <div class="menu-bar bg-danger container-fluid border-top">
            <div class="container">
            <ul id="menu" class=" navcol fw-bold d-none d-md-inline-flex">
                <li class="p-21 px-4" >
                    <a class="text-white" href="<?php echo e(route('dashboard')); ?>"> <i class="bi pt-2 bi-chevron-down"></i><?php echo app('translator')->get('Tableau de bord '); ?> </a>
                </li>

                    
                        <li class="p-21 px-4" >
                            <a class="text-white" href="<?php echo e(route('add')); ?>"> <i class="bi pt-2 bi-chevron-down"
                                    class="menu-icon fa fa-bars"></i><?php echo app('translator')->get('Ajout produit'); ?>
                            </a>
                        </li>
        
                        <li class="p-21 px-4" >
                            <a class="text-white" href="<?php echo e(route('produit')); ?>"> <i class="bi pt-2 bi-chevron-down"></i><?php echo app('translator')->get('Liste des produits'); ?>
                            </a>
                        </li>


                
                <li class="p-21 px-4">
                    <a class="text-white" href="<?php echo e(route('waiting')); ?>"> <i
                          class="bi pt-2 bi-chevron-down"  ></i><?php echo app('translator')->get('Comande en attente'); ?>
                    </a>
                </li>

                
                <li class="p-21 px-4" >
                    <a class="text-white" href="<?php echo e(route('complet')); ?>"> <i
                         class="bi pt-2 bi-chevron-down"   ></i><?php echo app('translator')->get('Commandes terminées'); ?>
                    </a>
                </li>

                
                    <li class="p-21 px-4">
                        <a class="text-white" href="<?php echo e(route('stay')); ?>"> <i
                                class="bi pt-2 bi-chevron-down"></i><?php echo app('translator')->get('Souscription En attente'); ?>
                        </a>
                    </li>

                    
                    <li class="p-21 px-4" >
                        <a class="text-white"  href="<?php echo e(route('zubete')); ?>"> <i
                                class="bi pt-2 bi-chevron-down"></i><?php echo app('translator')->get('Souscription Terminée'); ?>
                        </a>
                    </li>
            </ul>
        </div>
    </nav>
</aside>
<?php /**PATH C:\laragon\www\e-commerce\boutique\resources\views/sidebar.blade.php ENDPATH**/ ?>